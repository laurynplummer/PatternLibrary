# Pattern Library

# Current Components 

1. Navigation Bar (Nav)
2. Header Element (carousel or just static)
3. A range of six button types
4. Jumbotron (call to action)
5. Footer possibly incorporating social media icon links etc.
6. Pagination
7. Grid System


# Download
Pattern Library is avaiable.... 

# Pattern Library
The Pattern Library can be found here:
https://laurynplummer.github.io/PatternLibrary/index.html
